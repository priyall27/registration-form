After downloading the project, kindly execute "npm i" or "npm install" command in your terminal
